let cached: unknown;
let cachedAt = 0;

type VercelRequest = { method?: string };
type VercelResponse = {
  status: (code: number) => VercelResponse;
  setHeader: (name: string, value: string) => void;
  json: (body: unknown) => void;
};

export default async function handler(request: VercelRequest, response: VercelResponse) {
  if (request.method !== 'GET') {
    response.setHeader('Allow', 'GET');
    return response.status(405).json({ error: 'Método no permitido.' });
  }

  const apiKey = process.env.COINGECKO_API_KEY;
  if (!apiKey) {
    return response.status(503).json({ error: 'Configura COINGECKO_API_KEY en las variables del proyecto.' });
  }

  if (cached && Date.now() - cachedAt < 45_000) {
    response.setHeader('Cache-Control', 'no-store');
    return response.status(200).json(cached);
  }

  try {
    const upstream = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=eur&order=market_cap_desc&per_page=100&page=1&sparkline=true&price_change_percentage=24h', {
      headers: { accept: 'application/json', 'x-cg-demo-api-key': apiKey },
    });
    if (!upstream.ok) {
      return response.status(upstream.status).json({ error: `CoinGecko respondió ${upstream.status}.` });
    }
    cached = await upstream.json();
    cachedAt = Date.now();
    response.setHeader('Cache-Control', 'no-store');
    return response.status(200).json(cached);
  } catch {
    return response.status(502).json({ error: 'No se pudo conectar con CoinGecko.' });
  }
}
